import React, { Component } from 'react';

import FormValidation from './FormValidation'
import './events/Events.css'

class App extends Component {
  render() {
    return (
      <div className="App">
        <FormValidation />
      </div>
    );
  }
}

export default App;
